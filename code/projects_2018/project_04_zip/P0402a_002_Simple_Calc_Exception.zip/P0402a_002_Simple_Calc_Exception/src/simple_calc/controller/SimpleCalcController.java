/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package simple_calc.controller;

import simple_calc.model.SimpleCalc;
import simple_calc.view.SimpleCalcControlPanel;
import simple_calc.view.SimpleCalcInputView;
import simple_calc.view.SimpleCalcOutputView;

/**
 * 簡単な電卓(整数計算．入力エラー（ゼロ除算，整数書式)は例外補足．但し，エラーメッセージはコンソール出力)
 * @author 飯島 正 (iijima@ae.keio.ac.jp)
 */
public class SimpleCalcController {

    private SimpleCalc calc = null;
    private SimpleCalcInputView inputView = null;
    private SimpleCalcOutputView outputView = null;
    private SimpleCalcControlPanel controlPanel = null;

    public SimpleCalcController(SimpleCalc calc,
            SimpleCalcInputView inputView,
            SimpleCalcOutputView outputView,
            SimpleCalcControlPanel controlPanel) {
        this.calc = calc;
        this.inputView = inputView;
        this.outputView = outputView;
        this.controlPanel = controlPanel;
    }

    private void setParams() {
        try {
            int x = Integer.parseInt(inputView.getXvalue());
            calc.setX(x);
        } catch (NumberFormatException e) {
            System.err.println("xフィールドの内容が整数書式ではない");
            inputView.setXvalue("0");
        }
        try {
            int y = Integer.parseInt(inputView.getYvalue());
            calc.setY(y);
        } catch (NumberFormatException e) {
            System.err.println("yフィールドの内容が整数書式ではない");
            inputView.setYvalue("0");
        }
    }

    public void add() {
        setParams();
        calc.add();
        outputView.update();
    }

    public void sub() {
        setParams();
        calc.sub();
        outputView.update();
    }

    public void mul() {
        setParams();
        calc.mul();
        outputView.update();
    }

    public void div() {
        setParams();
        try {
            calc.div();
        } catch (IllegalArgumentException e) {
            System.err.println(e.getMessage());
        }
        outputView.update();
    }
}
