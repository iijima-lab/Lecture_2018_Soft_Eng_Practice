/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package simple_calc.controller;

import simple_calc.model.SimpleCalc;
import simple_calc.view.SimpleCalcControlPanel;
import simple_calc.view.SimpleCalcInputView;
import simple_calc.view.SimpleCalcOutputView;

/**
 * 簡単な電卓(2018-05-07の授業でやったところまで；作成途中のため動かない)
 * @author 飯島 正 (iijima@ae.keio.ac.jp)
 */
public class SimpleCalcController {
    private SimpleCalc calc = null;
    private SimpleCalcInputView inputView = null;
    private SimpleCalcOutputView outputView = null;
    private SimpleCalcControlPanel controlPanel = null;
    
    public SimpleCalcController(SimpleCalc calc,
                        SimpleCalcInputView inputView,
                        SimpleCalcOutputView outputView,
                        SimpleCalcControlPanel controlPanel) {
        this.calc=calc;
        this.inputView = inputView;
        this.outputView = outputView;
        this.controlPanel =controlPanel;
    }
}
