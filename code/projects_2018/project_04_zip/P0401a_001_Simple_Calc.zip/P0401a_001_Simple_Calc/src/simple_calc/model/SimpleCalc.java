/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package simple_calc.model;

/**
 * 簡単な電卓(2018-05-07の授業でやったところまで；作成途中のため動かない)
 * @author 飯島 正 (iijima@ae.keio.ac.jp)
 */
public class SimpleCalc {
    
}
