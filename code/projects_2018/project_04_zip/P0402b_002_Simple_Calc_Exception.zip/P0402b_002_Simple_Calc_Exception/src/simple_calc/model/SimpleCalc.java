/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package simple_calc.model;

/**
 * 簡単な電卓(整数計算．入力エラー（ゼロ除算，整数書式)は例外補足．エラーメッセージ出力)
 * @author 飯島 正 (iijima@ae.keio.ac.jp)
 */
public class SimpleCalc {

    private int x = 0;
    private int y = 0;
    private int result = 0;

    public void add() {
        result = x + y;
    }

    public void sub() {
        result = x - y;
    }

    public void mul() {
        result = x * y;
    }

    public void div() {
        if (y == 0) {
            throw new IllegalArgumentException("division by zero");
        } else {
            result = x / y;
        }
    }

    public void setX(int x) {
        this.x = x;
    }
    public void setY(int y) {
        this.y = y;
    }
    public int getResult() {
        return( result );
    }

}
