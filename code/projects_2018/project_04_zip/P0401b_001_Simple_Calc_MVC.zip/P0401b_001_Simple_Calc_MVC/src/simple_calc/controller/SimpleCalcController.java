/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package simple_calc.controller;

import simple_calc.model.SimpleCalc;
import simple_calc.view.SimpleCalcControlPanel;
import simple_calc.view.SimpleCalcInputView;
import simple_calc.view.SimpleCalcOutputView;

/**
 * 簡単な電卓(一応，整数計算ができるが，エラー処理はしていない)
 * @author 飯島 正 (iijima@ae.keio.ac.jp)
 */
public class SimpleCalcController {

    private SimpleCalc calc = null;
    private SimpleCalcInputView inputView = null;
    private SimpleCalcOutputView outputView = null;
    private SimpleCalcControlPanel controlPanel = null;

    public SimpleCalcController(SimpleCalc calc,
            SimpleCalcInputView inputView,
            SimpleCalcOutputView outputView,
            SimpleCalcControlPanel controlPanel) {
        this.calc = calc;
        this.inputView = inputView;
        this.outputView = outputView;
        this.controlPanel = controlPanel;
    }

    private void setParams() {
        int x = Integer.parseInt( inputView.getXvalue() );
        int y = Integer.parseInt( inputView.getYvalue() );
        calc.setX(x);
        calc.setY(y);
    }

    public void add() {
        setParams();
        calc.add();
        outputView.update();
    }

    public void sub() {
        setParams();
        calc.sub();
        outputView.update();
    }

    public void mul() {
        setParams();
        calc.mul();
        outputView.update();
    }

    public void div() {
        setParams();
        calc.div();
        outputView.update();
    }
}
